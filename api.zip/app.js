// app.js
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const db = require("./models");
const PORT = process.env.PORT || 3000;
const userRoutes = require("./routes/user.routes");
const authRoutes = require("./routes/auth.routes");

app.use(bodyParser.json());

db.sequelize.sync().then(() => {
  console.log("Database synced.");
});

app.use("/api", userRoutes);
app.use("/api", authRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
