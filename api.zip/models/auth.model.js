const bcrypt = require('bcryptjs');

module.exports = (sequelize, DataTypes) => {
  const userAuth = sequelize.define("userAuth", {
    username: { type: DataTypes.STRING, unique: true },
    email: { type: DataTypes.STRING, unique: true },
    password: { type: DataTypes.STRING }
  });

  userAuth.beforeCreate(async (userAuth) => {
    userAuth.password = await bcrypt.hash(userAuth.password, 10);
  });

  return userAuth;
};
